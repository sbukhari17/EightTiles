/**
 * Used to hold coordinates for grid indexes
 */
public class Coordinate {
    int X;
    int Y;

    public Coordinate(int x, int y) {
        X = x;
        Y = y;
    }
}
